<?php
$host = 'localhost';
$user = 'root';       // Usuário padrão do XAMPP
$password = '';       // Senha vazia (default do XAMPP)
$database = 'eventos_corporativos'; // Nome do banco que você criou

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>
<?php
session_start();

function login($email, $senha) {
    global $conn;
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $usuario = $result->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['logado'] = true;
            $_SESSION['email'] = $email;
            return true;
        }
    }
    return false;
}

function estaLogado() {
    return isset($_SESSION['logado']) && $_SESSION['logado'] === true;
}

function logout() {
    session_unset();
    session_destroy();
    header("Location: ../admin/login.php");
    exit;
}
?>
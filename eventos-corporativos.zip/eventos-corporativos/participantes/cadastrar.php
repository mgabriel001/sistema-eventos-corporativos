<?php
require_once '../config/auth.php';
require_once '../config/database.php';

if (!estaLogado()) {
    header("Location: ../admin/login.php");
    exit;
}

$capitais = [
    'Aracaju', 'Belém', 'Belo Horizonte', 'Boa Vista', 'Brasília',
    'Campo Grande', 'Cuiabá', 'Curitiba', 'Florianópolis', 'Fortaleza',
    'Goiânia', 'João Pessoa', 'Macapá', 'Maceió', 'Manaus', 'Natal',
    'Palmas', 'Porto Alegre', 'Porto Velho', 'Recife', 'Rio Branco',
    'Rio de Janeiro', 'Salvador', 'São Luís', 'São Paulo', 'Teresina', 'Vitória'
];

// Verifica se o ID foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ../admin/dashboard.php");
    exit;
}

$id = (int)$_GET['id'];
$erro = '';
$participante = null;

// Busca o participante no banco
$sql = "SELECT * FROM participantes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: ../admin/dashboard.php");
    exit;
}

$participante = $result->fetch_assoc();

// Processa o formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome_completo', FILTER_SANITIZE_STRING);
    $setor = filter_input(INPUT_POST, 'setor', FILTER_SANITIZE_STRING);
    $cidade = filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_STRING);
    $data_checkin = filter_input(INPUT_POST, 'data_checkin', FILTER_SANITIZE_STRING);
    
    if (empty($nome) || empty($setor) || empty($cidade) || empty($data_checkin)) {
        $erro = "Todos os campos são obrigatórios!";
    } else {
        $sql = "UPDATE participantes SET nome_completo = ?, setor = ?, cidade = ?, data_checkin = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $nome, $setor, $cidade, $data_checkin, $id);
        
        if ($stmt->execute()) {
            header("Location: ../admin/dashboard.php");
            exit;
        } else {
            $erro = "Erro ao atualizar participante: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Participante - Sistema de Eventos</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Editar Participante</h1>
        
        <?php if (!empty($erro)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="nome_completo">Nome Completo:</label>
                <input type="text" id="nome_completo" name="nome_completo" 
                       value="<?php echo htmlspecialchars($participante['nome_completo']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="setor">Setor:</label>
                <select id="setor" name="setor" required>
                    <option value="Tecnologia" <?php echo $participante['setor'] === 'Tecnologia' ? 'selected' : ''; ?>>Tecnologia</option>
                    <option value="Administrativo" <?php echo $participante['setor'] === 'Administrativo' ? 'selected' : ''; ?>>Administrativo</option>
                    <option value="Projeto" <?php echo $participante['setor'] === 'Projeto' ? 'selected' : ''; ?>>Projeto</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="cidade">Cidade:</label>
                <select id="cidade" name="cidade" required>
                    <?php foreach ($capitais as $capital): ?>
                        <option value="<?php echo htmlspecialchars($capital); ?>" 
                            <?php echo $participante['cidade'] === $capital ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($capital); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="data_checkin">Data de Check-in:</label>
                <input type="datetime-local" id="data_checkin" name="data_checkin" 
                       value="<?php echo date('Y-m-d\TH:i', strtotime($participante['data_checkin'])); ?>" required>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Atualizar</button>
                <a href="../admin/dashboard.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>
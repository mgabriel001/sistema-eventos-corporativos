<?php
require_once '../config/auth.php';
require_once '../config/database.php';

if (!estaLogado()) {
    header("Location: ../admin/login.php");
    exit;
}

// Verifica se o ID foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ../admin/dashboard.php");
    exit;
}

$id = (int)$_GET['id'];

// Executa a exclusão
$sql = "DELETE FROM participantes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: ../admin/dashboard.php");
exit;
?>
<?php
require_once '../config/auth.php';
require_once '../config/database.php';

if (!estaLogado()) {
    header("Location: login.php");
    exit;
}

$sql = "SELECT * FROM participantes";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Participantes</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Participantes do Evento</h1>
        <a href="../participantes/cadastrar.php" class="btn">Novo Participante</a>
        <a href="logout.php" class="btn btn-sair">Sair</a>
        
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Setor</th>
                    <th>Cidade</th>
                    <th>Check-in</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['nome_completo'] ?></td>
                    <td><?= $row['setor'] ?></td>
                    <td><?= $row['cidade'] ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($row['data_checkin'])) ?></td>
                    <td>
                        <a href="../participantes/editar.php?id=<?= $row['id'] ?>" class="btn">Editar</a>
                        <a href="../participantes/excluir.php?id=<?= $row['id'] ?>" class="btn btn-excluir">Excluir</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
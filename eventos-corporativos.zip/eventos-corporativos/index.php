<?php
require_once 'config/auth.php';

if (estaLogado()) {
    header("Location: admin/dashboard.php");
} else {
    header("Location: admin/login.php");
}
exit;
?>